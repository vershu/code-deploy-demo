# codedeploylab
This lab is to show how a AWS Code Pipeline is created using AWS Code Build, AWS Code Deploy.
